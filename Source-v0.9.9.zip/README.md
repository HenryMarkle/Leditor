# Henry's Leditor

An alternative to the current Rain World's official level editor, powered by .NET C# and Raylib.
Currently it's in *beta testing stage*.

## Features

- All of the tools the offical leditor provides and more.
- Full compatiblity with the official leditor.
- Better mouse & keyboard controls and shortcuts that can be customized.
- Better performance overral, with 60 FPS.

