namespace Leditor.Lingo.Drizzle;

public interface ILingoListDuplicate
{
    ILingoListDuplicate duplicate();
}